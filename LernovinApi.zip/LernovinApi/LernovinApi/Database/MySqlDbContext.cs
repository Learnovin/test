﻿using LernovinApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LernovinApi.Database
{
    public class MySqlDbContext: DbContext
    {

        public DbSet<Person> Person { get; set; }
        
        public MySqlDbContext(DbContextOptions<MySqlDbContext> options) : base(options)
        {
                
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Person>()
                .HasIndex(p => p.NationalCode)
                .IsUnique();

            builder.Entity<Person>()
            .Property(f => f.Id)
            .ValueGeneratedOnAdd();
        }


    }
}
