﻿using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LernovinApi.Models
{
    public class BaseModel
    {

        public int Id { get; set; }

        public bool IsActive { get; set; }

        [Required]
        public int CreatedBy { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; }

        [Timestamp]
        [Required]
        public DateTime UpdatedAt { get; set; }

        public bool? IsDeleted { get; set; }
        
        public int? DeletedBy { get; set; }

        public DateTime? DeletedAt { get; set; }


        public BaseModel()
        {
            this.CreatedAt = DateTime.Now;
        }
    }
}
